<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dibuja aquí</title>
    <style>
        #canvas {
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <canvas id="canvas" width="400" height="300"></canvas>

    <script>
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');

        let isDrawing = false;
        
        canvas.addEventListener('mousedown', (e) => {
            isDrawing = true;
            ctx.beginPath();
            ctx.moveTo(e.offsetX, e.offsetY);
        });

        canvas.addEventListener('mousemove', (e) => {
            if (isDrawing) {
                ctx.lineTo(e.offsetX, e.offsetY);
                ctx.stroke();
            }
        });

        canvas.addEventListener('mouseup', () => {
            isDrawing = false;
        });

        canvas.addEventListener('mouseleave', () => {
            isDrawing = false;
        });
    </script>
</body>
</html>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir y Manipular Imagen en Canvas</title>
</head>
<body>
    <input type="file" accept="image/*" onchange="loadImage(event)">
    <br>
    <canvas id="canvas" width="400" height="300" style="border: 1px solid #ccc;"></canvas>

    <script>
        function loadImage(event) {
            const file = event.target.files[0];
            const canvas = document.getElementById('canvas');
            const ctx = canvas.getContext('2d');

            const reader = new FileReader();
            reader.onload = function(e) {
                const img = new Image();
                img.onload = function() {
                    // Ajustar el tamaño del canvas al tamaño de la imagen
                    canvas.width = img.width;
                    canvas.height = img.height;

                    // Dibujar la imagen en el canvas
                    ctx.drawImage(img, 0, 0);

                    // Ejemplo: Dibujar un rectángulo rojo sobre la imagen
                    ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
                    ctx.fillRect(50, 50, 100, 100); // Dibuja un rectángulo semitransparente
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    </script>
</body>
</html>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir y Manipular Imagen en Canvas</title>
    <style>
        /* Estilos para los botones */
        .button-container {
            margin-top: 10px;
        }
        .button {
            padding: 10px 20px;
            font-size: 16px;
            margin-right: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Botón para subir imagen -->
    <label for="uploadImage" class="button">Subir Imagen</label>
    <input type="file" id="uploadImage" style="display: none;" accept="image/*" onchange="loadImage(event)">

    <!-- Contenedor para los botones de acción -->
    <div class="button-container">
        <button class="button" onclick="clearCanvas()">Borrar Dibujo</button>
        <button class="button" onclick="clearImage()">Eliminar Imagen</button>
    </div>

    <canvas id="canvas" width="400" height="300" style="border: 1px solid #ccc;"></canvas>

    <script>
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');
        let img = null;

        function loadImage(event) {
            const file = event.target.files[0];
            const reader = new FileReader();
            reader.onload = function(e) {
                img = new Image();
                img.onload = function() {
                    drawImageOnCanvas();
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }

        function drawImageOnCanvas() {
            const scaleFactor = Math.min(canvas.width / img.width, canvas.height / img.height);
            const scaledWidth = img.width * scaleFactor;
            const scaledHeight = img.height * scaleFactor;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, (canvas.width - scaledWidth) / 2, (canvas.height - scaledHeight) / 2, scaledWidth, scaledHeight);
        }

        function clearCanvas() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }

        function clearImage() {
            img = null;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        }
    </script>
</body>
</html>